const envList = [{"envId":"cloud1-6g8g347t9288a984","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}