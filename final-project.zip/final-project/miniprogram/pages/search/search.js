// pages/search/search.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        hall: ['所有食堂','紫荆', '芝兰', '玉树', '丁香'],
        sort: ['评分优先','价格降序','价格升序'],
        hall_index: 0,
        sort_index: 0,
    },
    bindPickerChange_sort: function(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
          sort_index: e.detail.value
        })
      },
      bindPickerChange_hall: function(e) {
        console.log('picker发送选择改变，携带值为', e.detail.value)
        this.setData({
          hall_index: e.detail.value
        })
      },
      search: function(e) {
        var that = this
        wx.navigateTo({
          url: '../search/search?search_word=' + that.data.search_word,
          success: function(res) {
            console.log("yes")
          }
          })
      },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})